ဒီဟာက Python မလိုတဲ့ Static Animation Website ပါ။
1. ZIP ဖြည်ပါ။
2. index.html ကို browser နဲ့ဖွင့်ပြီး စမ်းကြည့်ပါ။
3. အင်တာနက်ကနေ Link ရဖို့ ဒီ folder ကို GitHub repository တစ်ခုထဲ upload လုပ်ပြီး Settings > Pages > Deploy from a branch > main / root ကိုရွေးပါ။
4. GitHub Pages ပေးတဲ့ https://...github.io/... လင့်ခ်ကို Telegram ကနေ မျှဝေနိုင်ပါတယ်.
မှတ်ချက်: ခွေးပုံကို အင်тернетမှရယူတာဖြစ်လို့ online ဖြစ်ရပါမယ်။ Camera က mock animation ဖြစ်ပြီး တကယ့်ဓာတ်ပုံမရိုက်ပါ။
